# -*- coding: utf-8 -*-
"""星座组合穷举（小规模、人工候选集）—— 目标可换（GD_OBJ）。"""
import itertools, json, os, sys
sys.path.insert(0, '.'); sys.path.insert(0, 'tools')
import tune_devotion as TD
from gd import devotion as DV

cur = dict(TD.CUR)
base = TD.ev(cur)
G = TD.groups()
NAME = {i: (g.get('name') or str(i)) for i, g in G.items()}
have = {}
for r in cur:
    idx, _ = DV.constellation_of(r)
    if idx is not None:
        have.setdefault(idx, []).append(r)
BY = {}
for idx, g in G.items():
    n = g.get('name')
    if n and len(g['stars']) <= 6 and n not in BY:
        BY[n] = (idx, g)

def cand_of(add=(), ref=()):
    recs = [r for r in cur if not any(r in have.get(BY[n][0], []) for n in ref)]
    for n in add:
        if n not in BY:
            return None
        recs += BY[n][1]['stars']
    return recs

def ok(recs):
    try:
        o, _m, _g, _ = DV.check_affinity([{'record': r} for r in recs]); return bool(o)
    except Exception:
        return True

UP = ('乌龟', '海鳗', '抉择之地', '铁锤')
A = ('螳螂', '猫头鹰', '豺狼', '狐狸', '老鼠', '拜斯迈的羁绊', '蝙蝠', '铁砧', '夜爪', '鹰隼', '雄鹿', '公牛', '狮子')
CAND = [
    ('① 只加 螳螂',              ('螳螂',), ()),
    ('② 只加 猫头鹰',            ('猫头鹰',), ()),
    ('③ 只加 豺狼',              ('豺狼',), ()),
    ('④ 退乌龟 → 螳螂+猫头鹰',    ('螳螂', '猫头鹰'), ('乌龟',)),
    ('⑤ 退龟鳗抉 → 螳螂+猫头鹰',   ('螳螂', '猫头鹰'), ('乌龟', '海鳗', '抉择之地')),
    ('⑥ 退龟鳗抉 → 螳螂+豺狼',     ('螳螂', '豺狼'), ('乌龟', '海鳗', '抉择之地')),
    ('⑦ 退龟鳗抉铁 → 螳螂+猫头鹰',  ('螳螂', '猫头鹰'), UP),
    ('⑧ 退龟鳗抉铁 → 螳螂+猫头鹰+豺狼', ('螳螂', '猫头鹰', '豺狼'), UP),
    ('⑨ 退龟鳗抉铁 → 螳螂+猫头鹰+狐狸', ('螳螂', '猫头鹰', '狐狸'), UP),
    ('⑩ 退龟鳗抉铁 → 螳螂+猫头鹰+老鼠', ('螳螂', '猫头鹰', '老鼠'), UP),
    ('⑪ 退龟鳗抉铁 → 螳螂+猫头鹰+拜斯迈', ('螳螂', '猫头鹰', '拜斯迈的羁绊'), UP),
    ('⑫ 退龟鳗抉铁 → 螳螂+猫头鹰+蝙蝠', ('螳螂', '猫头鹰', '蝙蝠'), UP),
    ('⑬ 退龟鳗抉铁 → 螳螂+猫头鹰+铁砧', ('螳螂', '猫头鹰', '铁砧'), UP),
    ('⑭ 退龟鳗抉铁 → 螳螂+猫头鹰+夜爪', ('螳螂', '猫头鹰', '夜爪'), UP),
    ('⑮ 退龟鳗抉铁 → 螳螂+猫头鹰+雄鹿', ('螳螂', '猫头鹰', '雄鹿'), UP),
    ('⑯ 退龟鳗抉铁 → 螳螂+猫头鹰+鹰隼', ('螳螂', '猫头鹰', '鹰隼'), UP),
]
print('基线 %s ｜ 评分目标 %s ｜ 现有 %d 星点'
      % (format(TD._sc(base), ',.0f'), TD._OBJ.label(TD.OBJ), len(cur)))
print()
print('%-34s %4s %-5s %12s %9s' % ('方案', '星点', '亲和', '评分', '增益'))
print('-' * 72)
best = None
for tag, add, ref in CAND:
    recs = cand_of(add, ref)
    if recs is None:
        print('%-34s （星座名缺失）' % tag); continue
    if len(recs) > TD.BUDGET:
        print('%-34s %4d  （超预算 %d）' % (tag, len(recs), TD.BUDGET)); continue
    a = ok(recs)
    d = {r: 1 for r in recs}
    v = TD.ev(d)
    sc = TD._sc(v)
    print('%-34s %4d %-5s %12s %8.2f%%' % (tag, len(recs), '✓' if a else '✗',
          format(sc, ',.0f'), sc / TD._sc(base) * 100 - 100))
    if a and (best is None or sc > best[0]):
        best = (sc, v, tag, len(recs), recs, add, ref)
print()
print('★ 最优：%s ｜ %d/36 星点 ｜ 评分 %s（%+.2f%%）｜ 面板 %s'
      % (best[2], best[3], format(best[0], ',.0f'), best[0] / TD._sc(base) * 100 - 100,
         format(best[1][0], ',.0f')))
print('   加 %s ｜ 退 %s' % ('+'.join(best[5]), '+'.join(best[6]) or '无'))
json.dump({'base': list(base[:2]), 'objective': TD.OBJ, 'base_score': TD._sc(base),
           'best': {'tag': best[2], 'score': best[0], 'panel': best[1][0],
                    'vs': best[1][1], 'n': best[3], 'add': list(best[5]),
                    'refund': list(best[6])},
           'records': sorted(best[4])},
          open('data/scratch/devotion_combo_pierce.json', 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print('已落 data/scratch/devotion_combo_pierce.json')
