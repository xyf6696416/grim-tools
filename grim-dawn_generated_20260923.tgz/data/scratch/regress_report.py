# -*- coding: utf-8 -*-
"""极限 BD 回归报告：读多次 sweep 的 _sweep.json，排名 + 门控 + 与历史基线对比。

用法:
    python data/scratch/regress_report.py <noalloc_dir> [alloc_dir]
"""
import json
import os
import sys

sys.path.insert(0, ".")

# ★ 2026-09-20 重设：**历史基线清空**。
#   原因：B 口径（注入加点）本轮**退役** —— 自动加点器会给双持形态塞 24 点进
#   `wpattack1/2/3`，武器池 ΣW 撑过 100 ⇒ 默认攻击权重归零 ⇒ 主输出一次不出现
#   （`docs/pitfalls.md` #53，实测 −50%）。修好加点器前不用它做任何结论。
#   v5 的旧值（B 口径）只作留档，可从整包归档
#   `E:/xz/Archives/grim-dawn_plans_before_reissue_*.tar.gz` 取回。
#   ⇒ 现在只有 **A 口径（真实存档，可落地）** 一套数，回归差一栏失去意义。
HIST = {}

VALID_NB = ["werewolf", "human", "wereraven", "berserker_nightblade",
            "wolf_nightblade", "wolf_nightblade_fast", "raven_nightblade", "avalanche"]


def load(d):
    p = os.path.join(d, "_sweep.json")
    if not os.path.exists(p):
        return None
    return json.load(open(p, encoding="utf-8"))


def rows_of(d):
    s = load(d)
    if not s:
        return {}, None
    return {r["arch"]: r for r in s.get("rows", [])}, s


def main():
    noalloc_dir = sys.argv[1] if len(sys.argv) > 1 else "data/plans/lv73_A"
    alloc_dir = sys.argv[2] if len(sys.argv) > 2 else "data/plans/lv73_B"

    ra, sa = rows_of(noalloc_dir)
    rb, sb = rows_of(alloc_dir)

    for tag, s in (("真实存档口径", sa), ("注入加点口径", sb)):
        if s:
            print("[%s] char=%s n=%s iters=%s wall=%.1fs proj=%s"
                  % (tag, s.get("char"), s.get("n"), s.get("iters"),
                     s.get("wall") or 0, s.get("proj")))
    print()

    from gd import skillprov as SP
    from gd import enemy as E  # noqa: F401

    def gate(arch):
        try:
            r = SP.arch_report(arch, level=71)
            return ("✗ 门控" if not r["ok"] else "✓")
        except Exception as e:
            return "?%s" % str(e)[:12]

    # 专精归属（决定 Sam 能不能选）
    archs = json.load(open("data/archetypes.json", encoding="utf-8"))

    def allowed(arch):
        m = str((archs.get(arch) or {}).get("mastery") or "")
        return "N+B 可选" if m == "class10" else ("不可选(%s)" % m if m else "?")

    hdr = ("%-22s %-13s %6s  %12s %12s  %10s  %s"
           % ("形态", "专精", "门控", "真实存档", "注入加点", "历史基线", "回归差"))
    print(hdr)
    print("-" * len(hdr))

    all_archs = sorted(set(list(ra) + list(rb) + list(HIST) + VALID_NB))
    out = []
    for a in all_archs:
        va = ra.get(a, {}).get("dps")
        vb = rb.get(a, {}).get("dps")
        h = HIST.get(a)
        if vb and h:
            diff = "%+.1f%%" % (vb / h * 100 - 100)
        elif vb is None:
            diff = "—"
        else:
            diff = "(no hist)"
        out.append((a, allowed(a), gate(a), va, vb, h, diff))

    # 排序：真实存档优先，缺失则用注入
    def key(r):
        v = r[3] if r[3] else (r[4] or 0)
        return -v

    out.sort(key=key)
    for a, al, g, va, vb, h, diff in out:
        f = lambda x: format(int(x), ",") if x else "—"
        print("%-22s %-13s %6s  %12s %12s  %12s  %s"
              % (a, al, g, f(va), f(vb), f(h), diff))
    print()
    print("说明：真实存档 = Sam 现有技能/星座 + 形态装备（不注入加点，可落地）；")
    print("      注入加点 = GD_SKILL_JSON 整体替换核心加点 —— **本轮已退役**（见文件头说明）。")
    print("      ★ 只有 A 口径可信；「形态装备」与「现穿」是否一致见 BUILD_Sam_lv73.md。")


if __name__ == "__main__":
    main()
