{
 "头部": [
  "it12309",
  "it2866",
  null,
  null,
  null
 ],
 "项链": [
  "it874",
  "it2823",
  "it453",
  null,
  null
 ],
 "胸甲": [
  "it1800",
  "it2896",
  null,
  null,
  null
 ],
 "腿甲": [
  "it1442",
  "it2872",
  null,
  null,
  null
 ],
 "靴子": [
  "it1142",
  "it2879",
  null,
  null,
  null
 ],
 "手套": [
  "it1222",
  "it2835",
  null,
  null,
  null
 ],
 "戒指1": [
  "it977",
  "it2873",
  "it411",
  null,
  null
 ],
 "戒指2": [
  "it15278",
  "it2873",
  "it453",
  "pre3613",
  "suf6447"
 ],
 "腰带": [
  "it1070",
  null,
  null,
  null,
  null
 ],
 "肩甲": [
  "it12354",
  "it2872",
  null,
  "pre3717",
  "suf6409"
 ],
 "勋章": [
  "it798",
  "it2829",
  "it453",
  null,
  null
 ],
 "圣物": [
  "it1516",
  null,
  null,
  null,
  null
 ],
 "主手": [
  "it15021",
  "it2860",
  "it397",
  null,
  null
 ],
 "副手": [
  "it1891",
  "it2849",
  "it397",
  null,
  null
 ]
}