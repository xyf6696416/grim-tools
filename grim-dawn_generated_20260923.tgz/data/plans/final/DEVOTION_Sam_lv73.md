# 星座加点方案（**单星粒度 + 精确亲和力**）—— Sam lv73

> 生成：2026-09-21 ｜ 形态 `wolf_nightblade_fast` ｜ 装备 `data/plans/pivot/x_total_fix2.json`
> 方案文件：`data/plans/pivot/devotion_star_plan.json` ｜ 复现见文末
> **状态：未落档**（`--apply` 才会写存档）。

---

## 一、点数对账

| 项 | 值 | 说明 |
|---|---|---|
| 已点亮节点 | **36** | 8 颗星座的节点合计（含 2 个 proc 节点） |
| 存档「已花」`total_devotion_points` | 36 | 与上一致 ⇒ **每个节点 1 点（proc 节点也要花点）** |
| 存档「未分配」`devotion_points` | **4** | |
| **池** | **40** | = 已花 + 未分配 |

## 二、亲和力（★ 这次是**精确**算的）

规则（官方指南）：*"Affinity is earned by **fully unlocking a Constellation**,
or through each star in the Crossroads Constellation."* ⇒ 数据里 **`given`** 就是完成奖励，
**`affinity`** 是门槛；**点一半不给亲和力**；十字路口在数据里是 **6 个「抉择之地」条目**（各 1 星、各 +1）。

| 项 | Ascendant | Order | Eldritch | Chaos | Primordial |
|---|---|---|---|---|---|
| 现状（8 颗点满） | **21** | 5 | 5 | 3 | 0 |
| 方案点满后 | **21** | 5 | 5 | 3 | 0 |

- 各所属星座门槛：狂战士需 **Ascendant 1** ✓ ｜ 螳螂需 **Ascendant 1** ✓
- **可达性（解锁顺序）**：✓ 两颗都能按顺序点出来。

> ⚠⚠ **曾经算出过一个 +20% 的方案（退「铁锤」＋「北海巨妖」＋「无名士兵」）—— 那是错的**：
> 近似的 `check_affinity`（每星 +1 主亲和力）把它俩放行了，而真门槛是
> 北海巨妖要 **Primordial 5**（Sam 是 **0**）、无名士兵要 **Ascendant 15 + Order 8**（Sam 是 21/**5**）⇒ **都点不出来**。
> 附带发现：**退「铁锤」本身也不合法** —— 退掉它少 4 点 Ascendant，会让**「刺客」的门槛不够**
> （刺客需 Asc 6 + **Order 4**，退完只剩 Order 2）。搜索现在会自动撤销这种退款。详见陷阱 **#73**。

## 三、方案（4 个剩余点）

| 动作 | 星座 | 节点 | 关键字段 | 面板累计 |
|---|---|---|---|---|
| 补 | **狂战士**（`tier2_25`） | 25a | +20 OA ｜ +300 生命 | |
| | | 25d | **+50% 物理** ｜ **+50% 流血** ｜ +15% 眩晕抗 | |
| | | 25e | **+50% 流血系**（时长/倍率） | 146,184（**+5.45%**） |
| 补 | **螳螂**（`tier1_44`） | 44a（根） | **+15% 穿刺** ｜ +20 护甲保护 | 146,694（**+0.35%**） |

- 起点 `138,634` → **146,694（+5.81%）** ｜ 实战 `161,562` → `170,955`
- 节点 **40 / 40**（池刚好用完）｜ **无退款**（退款候选因亲和力不可行已被自动撤销）
- 原存档的 2 个 proc **全部保留**（`tier1_08e_skill` 刺客的标记 / `tier2_06g_skill`）

## 四、已知边界

1. **proc 节点不计收益**（模型缺「触发率 × 指派」门控）⇒ 本方案避开 proc，实际收益可能更高。
2. **模型盲区**：DPS 模型不算防御 —— 买「螳螂」主要是冲那 +15% 穿刺。
3. ★ **亲和力现在会精确校验 + 查解锁顺序**（`tune_devotion` 内置）；
   但**点数（40）是否真能到手**仍取决于游戏里那 4 点未分配是否可花（存档字段说的，未落档前不变）。

## 五、复现

```bash
PY=/c/Users/Administrator/.workbuddy/binaries/python/envs/default/Scripts/python.exe
PLAN=data/plans/pivot/x_total_fix2.json GD_PROJ_HITS=1 $PY tools/tune_devotion.py --realloc
PLAN=data/plans/pivot/x_total_fix2.json SKILL_SRC=data/scratch/skill_opt.json \
  DEV_SRC=data/plans/pivot/devotion_star_plan.json GD_PROJ_HITS=1 $PY tools/eval_build_variants.py
```
