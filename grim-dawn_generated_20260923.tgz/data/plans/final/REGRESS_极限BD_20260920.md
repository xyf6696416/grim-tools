# 全形态回归对拍 · lv73 极限 BD（Sam lv73 · 2026-09-20 重出）

> **本轮口径（v6）**：**只有 A 口径（真实存档技能 / 星座 + 形态装备 ⇒ 只换装备，可落地）**。
> B 口径（`GD_SKILL_JSON` 注入加点）**退役** —— 自动加点器会给双持形态塞 24 点进
> `wpattack1/2/3`，武器池 ΣW 撑过 100 ⇒ 默认攻击权重归零 ⇒ 主输出（野性利爪）一次不出现
> （`docs/pitfalls.md` #53，实测 −50%）。修好加点器前不用它做任何结论。
>
> **怎么读这张表**：A 口径下**技能来自存档**，所以每个形态算的是
> 「**Sam 的真实技能 + 该形态的装备池**」。Sam 是狼系（`class10` / 变身系），
> 因此**狼系三形态**（`werewolf` / `wolf_nightblade` / `wolf_nightblade_fast`）与它同源，
> 数值才有直接意义；`raven_nightblade` 这类**异形态**会出现「狼技能 + 鸦装备」的错配，
> 高于狼系**不代表更强**（见 `BUILD_Sam_lv73.md` §一）。
>
> 普查参数：12 形态 × **400 轮 LNS** ｜ `--proj 1` ｜ 默认敌方池档。
> 复跑：`python tools/sweep_arch.py Sam --all --iters 400 --proj 1 \
>   --alloc-tpl 'data/scratch/_noalloc73_{arch}.json' --out-dir data/plans/lv73_A \
>   --log-dir data/scratch/lv73_A`

[真实存档口径] char=Sam n=12 iters=400 wall=100.1s proj=1

形态                     专精                门控          真实存档         注入加点        历史基线  回归差
---------------------------------------------------------------------------------------
raven_nightblade       N+B 可选             ✓       153,444            —             —  —
berserker_nightblade   N+B 可选             ✓       152,438            —             —  —
fangs                  不可选(other)      ✗ 门控       152,438            —             —  —
human                  N+B 可选             ✓       152,438            —             —  —
necro_inquisitor       不可选(class08)       ✓       152,438            —             —  —
oathkeeper_nightblade  不可选(class09)       ✓       152,438            —             —  —
soldier_nightblade     不可选(class01)       ✓       152,438            —             —  —
wereraven              N+B 可选             ✓       152,438            —             —  —
werewolf               N+B 可选             ✓       152,438            —             —  —
wolf_nightblade        N+B 可选             ✓       152,438            —             —  —
wolf_nightblade_fast   N+B 可选             ✓       152,438            —             —  —
avalanche              N+B 可选             ✓        16,496            —             —  —

说明：真实存档 = Sam 现有技能/星座 + 形态装备（不注入加点，可落地）；
      注入加点 = GD_SKILL_JSON 整体替换核心加点 —— **本轮已退役**（见文件头说明）。
      ★ 只有 A 口径可信；「形态装备」与「现穿」是否一致见 BUILD_Sam_lv73.md。
